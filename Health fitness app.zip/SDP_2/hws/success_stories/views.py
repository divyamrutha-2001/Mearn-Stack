from django.shortcuts import render

# Create your views here.
def stories_view(request):
    return render(request,"success_stories/dss.html")

def ustories_view(request):
    return render(request,"success_stories/story.html")

def enterstories_view(request):
    return render(request,"success_stories/ss.html")